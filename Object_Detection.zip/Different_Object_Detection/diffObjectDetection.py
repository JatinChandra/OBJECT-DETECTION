import cv2

eyeDetect = cv2.CascadeClassifier('xmldata/haarcascade_eye.xml')
faceDetect = cv2.CascadeClassifier('xmldata/haarcascade_frontalface_default.xml')
catDetect = cv2.CascadeClassifier('xmldata/haarcascade_frontalcatface_extended.xml')
personDetect = cv2.CascadeClassifier('xmldata/haarcascade_fullbody.xml')
lower_bodyDetect = cv2.CascadeClassifier('xmldata/haarcascade_lowerbody.xml')
upper_bodyDetect = cv2.CascadeClassifier('xmldata/haarcascade_upperbody.xml')


faceimg = cv2.imread('images/face.jpg')
catimg = cv2.imread('images/catbody2.jpg')
personimg = cv2.imread('images/person2.jpg')

grayface = cv2.cvtColor(faceimg, cv2.COLOR_BGR2GRAY)
graycat = cv2.cvtColor(catimg, cv2.COLOR_BGR2GRAY)
grayperson = cv2.cvtColor(personimg, cv2.COLOR_BGR2GRAY)


faces = faceDetect.detectMultiScale(grayface, scaleFactor=1.1, minNeighbors=5)
cats = catDetect.detectMultiScale(graycat, scaleFactor=1.1, minNeighbors=5)
persons = personDetect.detectMultiScale(grayperson, scaleFactor=1.1, minNeighbors=5)
lower_bodys = lower_bodyDetect.detectMultiScale(grayperson, scaleFactor=1.1, minNeighbors=5)
upper_bodys = upper_bodyDetect.detectMultiScale(grayperson, scaleFactor=1.1, minNeighbors=5)

for (x, y, w, h) in faces:
    cv2.rectangle(faceimg, (x, y), (x+w, y+h), (255, 0, 0), 2)
    roi_gray = grayface[y:y+h, x:x+w]
    roi_color = faceimg[y:y+h, x:x+w]
    eyes = eyeDetect.detectMultiScale(roi_gray)
    for (ex, ey, ew, eh) in eyes:
        cv2.rectangle(roi_color, (ex, ey), (ex+ew, ey+eh), (0, 255, 0), 2)

for (x, y, w, h) in cats:
    cv2.rectangle(catimg, (x, y), (x+w, y+h), (0, 0, 255), 2)

for (x, y, w, h) in persons:
    cv2.rectangle(personimg, (x, y), (x+w, y+h), (120, 100, 25), 2)

for (x, y, w, h) in lower_bodys:
    cv2.rectangle(personimg, (x, y), (x+w, y+h), (10, 100, 125), 2)

for (x, y, w, h) in upper_bodys:
    cv2.rectangle(personimg, (x, y), (x+w, y+h), (220, 100, 215), 2)


frameName = 'Face'
cv2.namedWindow(frameName, cv2.WINDOW_NORMAL)
cv2.resizeWindow(frameName, 400, 300)
cv2.imshow(frameName, faceimg)

frameName = 'cat'
cv2.namedWindow(frameName, cv2.WINDOW_NORMAL)
cv2.resizeWindow(frameName, 400, 300)
cv2.imshow(frameName, catimg)

frameName = 'person'
cv2.namedWindow(frameName, cv2.WINDOW_NORMAL)
cv2.resizeWindow(frameName, 400, 300)
cv2.imshow(frameName, personimg)

cv2.waitKey(0)
cv2.destroyAllWindows()
